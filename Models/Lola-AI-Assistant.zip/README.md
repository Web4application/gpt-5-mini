# Lola AI Assistant

Messenger-style AI with voice and journaling.